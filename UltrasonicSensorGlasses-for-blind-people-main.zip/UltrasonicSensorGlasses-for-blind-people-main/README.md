# UltrasonicSensorGlasses-for-blind-people
This is a product / project developed by a team of Five Members including Mithilesh Ghadge for the Engineering Clinics at Vellore Institute Of Technology.
An Arduino Project which made use of Arduino language.
The Hardware components included Arduino, Ultrasonic Sensor and a buzzer. Jumper wires were required for connections. A Battery is also required to power the Arduino.

This is project will help blind people alot to avoid obstacles in their path.
The Ultrasonic sensor senses the object and the buzzer makes a beeping sound which varies depending on the distance. This helps the blind determine how far the obstacle is.
For more technical explanantion refer the report / presentation

This is also a cheap and cost effective product and hence the poor can also afford it.
Arduino Uno - 300rs-500rs
Ultrasonic Distance Sensor Module - HC-SR04 - 60rs
Buzzer - 20rs
Jumper wires, Battery 9V - 50rs-100rs
Plastic glasses - 100rs
cap (optional for stable and comfort design) - 100rs

- 👋 Hi, I’m Mithilesh Ghadge
- Passionate Coder from India
- Instagram : https://www.instagram.com/mithileshghadge/
- Facebook : https://www.facebook.com/mitilesh.ghadge
